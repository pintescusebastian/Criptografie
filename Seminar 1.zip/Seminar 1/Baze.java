import java.io.*;

public class Baze{
    static int b1,b2;
    static String number ;
    static Console console = System.console(); 

    public static void main(String[] args) {
        if(console == null)
        {
            System.out.println("Consola nu functioneaza!");
            return;
        }

        number = console.readLine("Introduceti numarul: ");
        b1 = Integer.parseInt(console.readLine("Introduceti baza initiala (b1): "));
        b2 = Integer.parseInt(console.readLine("Introduceti a doua baza (b2): "));

        if (b1 < 2 || b1 > 26 || b2 < 2 || b2 > 26) {
            System.out.println("Bazele trebuie sa fie intre 2 și 26.");
            return;
        }

        try {
            int decimalValue = convertToDecimal(number, b1);
            String result = convertFromDecimal(decimalValue, b2);
            System.out.println("Numarul in baza " + b2 + " este: " + result);
        } catch (IllegalArgumentException e) {
            System.out.println("Eroare: " + e.getMessage());
        }

        try {
            System.out.println("Apasati Enter pentru a închide...");
            System.in.read();  
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static int convertToDecimal(String number, int base) {
        int value = 0;
        for (char c : number.toCharArray()) {
            int digit = Character.isDigit(c) ? c - '0' : Character.toUpperCase(c) - 'A' + 10;
            if (digit >= base) {
                throw new IllegalArgumentException("Cifra " + c + " nu este valida în baza " + base);
            }
            value = value * base + digit;
        }
        return value;
    }

    private static String convertFromDecimal(int number, int base) {
        if (number == 0) return "0";

        StringBuilder result = new StringBuilder();
        while (number > 0) {
            int remainder = number % base;
            char digit = (char) (remainder < 10 ? '0' + remainder : 'A' + (remainder - 10));
            result.append(digit);
            number /= base;
        }
        return result.reverse().toString();
    }
}